<!DOCTYPE html>
<?php session_start(); ?>
<?php require 'includes/connection.php'; ?>
 <html>
 <head>
 	<title>chat-box</title>

 	<!-- bootstrap-link -->
 	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
 	<!-- scc-link-file -->
 	<link rel="stylesheet" type="text/css" href="css/style_index.css">
  <!-- js-script link -->
  <!-- Remember to include jQuery :) -->
  <script
		  src="https://code.jquery.com/jquery-3.4.1.min.js"
		  integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
		  crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0/jquery.min.js"></script>
<!-- jQuery Modal -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.css" />

</head>
 <body>

<div id="container">
	<a href="includes/logout.php" style="text-decoration: none;"><h5 style="margin-left: 1250px;">Logout</h5></a>
	<h5 style="margin-top: -30px;color: green"><?php echo $_SESSION['sender'];?> is Logged in</h5>
	<div id="menu">

		<h3 class="text-center">Chat Message Box</h3>
	</div>


<!-- Modal HTML embedded directly into document -->
<div id="ex1" class="modal">
	<h5 class="text-center" id="new-msg">New Message</h5>
	<?php 
	if (isset($_POST['send'])) {

		$sender_name = $_SESSION['sender'];
		$message = $_POST['message'];
		$receiver_name = $_POST['receiver_name'];
		$user_id = $_SESSION['user_id'];

		$receiver_name = mysqli_real_escape_string($conn,$receiver_name);
		$message = mysqli_real_escape_string($conn,$message);
		$sender_name = mysqli_real_escape_string($conn,$sender_name);
		$user_id = mysqli_real_escape_string($conn,$user_id);


		$sql = "INSERT INTO messages (user_id,sender_name, receiver_name,message ) VALUES ('".$user_id."','".$sender_name."','".$receiver_name."', '".$message."')";

		if (mysqli_query($conn, $sql)) {
            header("Location:index.php?user=".$receiver_name);
		}
		 else {

			echo "Message sending failed...!";
		}
	}
	?>
	<form method="post">
		<div id="checking"></div>
		<input type="text" onkeyup="user_in_db()" placeholder="Username" id="receiver_name" name="receiver_name" class="form-control">
		<input type="hidden" name="user_id" value="">
		
	<textarea class="form-control textarea-pop" name="message" placeholder="Enter your message here"  required=""></textarea>
	<button class="btn btn-danger" id="send" type="submit" name="send">Send</button>
	</form>
	<h5 class="text-center" id="footer">Send To Client!</h5>
	<a href="#close-modal" rel="modal:close" class="close-modal ">Close</a>
</div>
<!-- Link to open the modal -->

	
	<div id="left-col">
		<div id="left-col-container ">
			<!-- end-of-right-column -->
			<div class="col-md-12 scroll">
				<div class="new-message text-center">
					<a href="#ex1" rel="modal:open" class="span" data-toggle="modal">New Message</a>
				</div>
					<?php
					$sql3 = "select * from messages where sender_name = '".$_SESSION['sender']."' ";
					$result3 = mysqli_query($conn,$sql3);
					while ($row3 = mysqli_fetch_assoc($result3)) {
						$id = $row3['id'];
						$user_id = $row3['user_id'];
						$receiver_name = $row3['receiver_name'];
						$profile = $row3['profile'];
						$last_message = $row3['message'];

						?>
					<a href="index.php?user_id=<?=$user_id ?>&username=<?=$receiver_name?>" style="text-decoration: none;">
					<div class="grey-back" style="border-radius: 0px" >
					<img width="50" height="50" style="margin-top: -5px" src="<?php echo $profile; ?>" class="img-fluid rounded-circle">
					<h6><b><?php echo $receiver_name; ?></b></h6><span style="margin-left: 190px;">Offline</span> 
					<p style="margin-bottom: -7px;margin-left: 45px;color: black;margin-top: -15px"><?php echo $last_message; ?></p>

					</div>
					</a>
						<?php
						
					}

					?>
			</div>
		</div>
	</div>

<div id="right-col">
	<div id="right-col-container">
		<div id="messages-container">
			<?php
			if (isset($_GET['user_id'])) {

			$sql5 = "select receiver_name,id,profile from messages where user_id = '".$_GET['user_id']."' ";
			$result5 = mysqli_query($conn,$sql5);
			$fecth = mysqli_fetch_assoc($result5);
			$sender_name = $fecth['receiver_name'];
			$profile = $fecth['profile'];
			?>
			<img width="50" height="50" src="<?php echo $profile ?>" class="img-fluid rounded-circle">
			<b><a href="#" style="font-size: 20px;text-decoration: none;"><?php echo $sender_name; ?></a></b>

			<span>Online</span>
			<?php 
			if (isset($_GET['user_id'])) {
				$user = $_GET['user_id'];
				$reciver = $_GET['username'];
			
			$sql2 = "select * from messages where user_id = '$user' AND receiver_name = '$reciver' ";
			$result2 = mysqli_query($conn,$sql2);
			while ($row2 = mysqli_fetch_assoc($result2)) {
				$sender_name = $row2['sender_name'];
				$receiver_name = $row2['receiver_name'];
				$message = $row2['message'];
				$arrival_time = $row2['arrival_time'];

				$receiver_name = mysqli_real_escape_string($conn,$receiver_name);
				$message = mysqli_real_escape_string($conn,$message);
				$sender_name = mysqli_real_escape_string($conn,$sender_name);
				$arrival_time = mysqli_real_escape_string($conn,$arrival_time);
					
?>
					
					<div id="bg-color" class="rounded" style="margin-left: 120px;background-color: lightblue;margin-top: 15px;width: 670px;height: 50px">
						<span style="margin-left: 30px"><?php echo $message; ?></span>
						<small style="margin-left: 320px;"><?php echo $arrival_time; ?></small>
					</div>
		<?php } } } ?>
						
			<!-- <div class="white-message">
					<a href="#" style="font-size: 16px">Me</a>
					<p>This message will show with white back </p>
			</div> -->
			
		</div>
	</div>
</div>

<textarea class="textarea" placeholder="Write Your message...">
</textarea>
	



  </div>


		<script type="text/javascript">
			function user_in_db(){
					var user = document.getElementById("receiver_name").value;
					 $.ajax({

                    url:'includes/action.php',
                    method:'post',
                    // cache:false,
                    data:{
                          receiver_name:user
                    },
                    success:function(response){
                    	document.getElementById("checking").innerHTML = response;
                        // $('#quantity_message').html(response);
                     console.log(response);
                     if (response== 'You can send message to this user') {
                     	console.log("Hello");
                     	alert("Hello World");
                     	
                     }
                     else{
                     	// document.getElementById("send").disabled = true;
                     }       
                    }	
                })
		}

		</script>
 </body>
</html>

