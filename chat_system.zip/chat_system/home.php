<!DOCTYPE html>
<html>
<head>
	<title>Index page</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

</head>
<body>

<div class="container">
	<div class="row">
		<div class="col-md-12">

			<div class="circle" style="background-color: gray;height: 600px;margin-top: 60px">
				
				<div>
					<img src="images/chat_profile.jpg" class="img-responsive" width="50px" height="50px" style="border-radius: 250px;margin-left: 30px;margin-top: 30px">
					<a href="" style="color: white;font-size: 20px;margin-left: 30px;"><b>Preeti</b><img style="margin-left: 5px;margin-top: -4px" src="images/online_icon1.png" width="15px;" height="15px">  </a>
					<p style="margin-left: 180px;color: black;margin-top: -30px">How are you..?</p>
					<p style="margin-left: 200px;font-size: 12px;margin-top: -10px">11:40:10 23 Sep 2019</p>
					
				</div>

				<div style="margin-top: -30px">
					<img src="images/chat_profile1.jpg" class="img-responsive" width="50px" height="50px" style="border-radius: 250px;margin-left: 1020px;margin-top: 30px">
					
					<p style="margin-left:900px;color: black;margin-top: -30px">I am fine</p>
					<p style="margin-left: 915px;font-size: 12px;margin-top: -10px">11:40:10 23 Sep 2019</p>
				</div>



				<div style="margin-top: -30px">
					<img src="images/chat_profile.jpg" class="img-responsive" width="50px" height="50px" style="border-radius: 250px;margin-left: 30px;margin-top: 30px">
					
					<p style="margin-left: 180px;color: black;margin-top: -30px">How are you..?</p>
					<p style="margin-left: 200px;font-size: 12px;margin-top: -10px">11:40:10 23 Sep 2019</p>
					
				</div>

				<div>
					<img src="images/chat_profile1.jpg" class="img-responsive" width="50px" height="50px" style="border-radius: 250px;margin-left: 1020px;margin-top: 30px">
					
					<p style="margin-left:900px;color: black;margin-top: -30px">I am fine</p>
					<p style="margin-left: 915px;font-size: 12px;margin-top: -10px">11:40:10 23 Sep 2019</p>
				</div>


				<div style="margin-top: -30px">
					<img src="images/chat_profile.jpg" class="img-responsive" width="50px" height="50px" style="border-radius: 250px;margin-left: 30px;margin-top: 30px">
					
					<p style="margin-left: 180px;color: black;margin-top: -30px">How are you..?</p>
					<p style="margin-left: 200px;font-size: 12px;margin-top: -10px">11:40:10 23 Sep 2019</p>
					
				</div>

				<div>
					<img src="images/chat_profile1.jpg" class="img-responsive" width="50px" height="50px" style="border-radius: 250px;margin-left: 1020px;margin-top: 30px">
					
					<p style="margin-left:900px;color: black;margin-top: -30px">I am fine</p>
					<p style="margin-left: 915px;font-size: 12px;margin-top: -10px">11:40:10 23 Sep 2019</p>
				</div>
				<div class="col-md-11 col-offset-4" style="margin-top:75px">
					<input type="text" name="message" class="form-control">
				</div>
				<div class="col-md-12 col-md-10">
					<a style="font-size: 19px;margin-left: 1000px;margin-top: -65px" class="btn btn-danger" href="">Send</a>
				</div>

				

				
				
			</div>


		</div>
	</div>
	
</div>

</body>
</html>