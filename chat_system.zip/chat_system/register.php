<!DOCTYPE html>
<?php require 'includes/connection.php'; ?>
<html>
	<head>
		<meta charset="utf-8">
		<title>RegistrationForm_v2 by Colorlib</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<script
		  src="https://code.jquery.com/jquery-3.4.1.min.js"
		  integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
		  crossorigin="anonymous"></script>

		<!-- MATERIAL DESIGN ICONIC FONT -->
		<link rel="stylesheet" href="fonts/material-design-iconic-font/css/material-design-iconic-font.min.css">
		
		<!-- STYLE CSS -->
		<link rel="stylesheet" href="css/style.css">
	</head>

	<body>
		<div class="wrapper" style="background-image: url('images/bg-registration-form-2.jpg');">
			<div class="inner">
<?php
		if(isset($_POST['submit'])){   
		
		 $name = $_POST['name'];
         $email = $_POST['email'];
         $user_id = $_POST['user_id'];
         $password = $_POST['password']; 
         $repeat_password = $_POST['repeat_password'];


		 $sql = "INSERT INTO register (name,user_id,email, password,repeat_password ) VALUES ('".$name."','".$user_id."','".$email."' ,'".$password."', '".$repeat_password."')";

		 if (mysqli_query($conn, $sql)) {

          echo "<h4 style='color:orange;margin-left:100px;margin-bottom:20px;font-size:20px'> Username added Successfully</h4>";
		 }
		  else {

			echo"<h4 style='color:red;margin-left:50px;margin-bottom:20px;font-size:20px'>User ID already exist,choose different ID</h4>";
           
        }
      }
?>
				<form action="" method="post">
					<h3>Registration Form</h3>
					<div id="checking"></div>
					<div class="form-wrapper">
						<label for="">Username</label>
						<input type="text" id="username" onkeyup="user_in_db()" name="name" class="form-control">
					</div>
					<div class="form-wrapper">
						<label for="">Email</label>
						<input type="text" name="email" required class="form-control">
					</div>
					<div class="form-wrapper">
						<label for="">User ID</label>
						<input type="text" name="user_id" required class="form-control">
					</div>
					<div class="form-wrapper">
						<label for="">Password</label>
						<input type="password" name="password" class="form-control">
					</div>
					<div class="form-wrapper">
						<label for="">Confirm Password</label>
						<input type="password" name="repeat_password" class="form-control">
					</div>
					<div class="checkbox">
						<label>
							<input type="checkbox"> I accept the Terms of Use & Privacy Policy.
							<span class="checkmark"></span>
						</label>
					</div>
					<button type="submit" id="register" name="submit" >Register Now</button><a style="color: white;text-decoration: none;" href="signin.php"><button>Login</a></button>
				</form>
			</div>
		</div>

		<script type="text/javascript">
			function user_in_db(){
					var user = document.getElementById("username").value;
					 $.ajax({

                    url:'includes/action.php',
                    method:'post',
                    // cache:false,
                    data:{
                          username:user
                    },
                    success:function(response){
                    	document.getElementById("checking").innerHTML = response;
                        // $('#quantity_message').html(response);
                     console.log(response);
                     if (response=="Exist") {
                     	// console.log("Hello");
                     	document.getElementById("register").disabled = true;
                     }       
                    }	
                   


                })
		}

		</script>
		
	</body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>