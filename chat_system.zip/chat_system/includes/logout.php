<?php
require 'connection.php';
session_start();
session_destroy();
$sql2 = "Update register SET status ='Offline' where name = '".$_SESSION['sender']."' ";
		$result2 = mysqli_query($conn,$sql2);
header('Location:../signin.php');
?>