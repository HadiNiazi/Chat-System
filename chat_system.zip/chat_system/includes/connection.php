
	<?php
	$conn = mysqli_connect("localhost","root","","chat_system");
	if (!$conn) {
		echo "Error occure".mysqli_error($conn);
	}
	else
	{
		// echo "Connected";
	}

	?>
