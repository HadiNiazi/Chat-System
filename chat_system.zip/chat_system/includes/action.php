<?php require 'connection.php'; ?>
<?php
if (isset($_POST['username'])) {

	$username = $_POST['username'];

	$sql = "select * from register where name = '$username' ";
	$result = mysqli_query($conn,$sql);
	if ($result) {
		if (mysqli_num_rows($result)>0) {

			echo "<p style='color:red;font-size:18px'>User already exist</p>";
		}
		else
		{
			echo "<p style='color:green;font-size:18px'>You can take this name</p>";
		}
	}
}

if (isset($_POST['receiver_name'])) {

	$username = $_POST['receiver_name'];

	$sql = "select * from register where name = '$username' ";
	$result = mysqli_query($conn,$sql);
	if ($result) {
		if (mysqli_num_rows($result)>0) {

			echo "You can send message to this user";
		}
		else
		{
			echo "No user exist";
		}
	}
}
?>