-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 29, 2019 at 01:21 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chat_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(3) NOT NULL,
  `sender_name` varchar(255) NOT NULL,
  `receiver_name` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  `arrival_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `profile` text DEFAULT NULL,
  `user_id` int(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `sender_name`, `receiver_name`, `message`, `arrival_time`, `profile`, `user_id`) VALUES
(1, 'Hadi Niazi', 'Faheem Khan', 'Hey how are you', '2019-09-27 13:53:17', 'images/img2.jpg', 3),
(16, 'Ayesha', 'Inami Khan', 'Hello Inami khan how are you', '2019-09-27 13:55:17', 'images/img2.jpg', 2),
(17, 'Ayesha', 'Amara', 'Hello amara kesi ho', '2019-09-27 14:01:10', 'images/chat_profile.jpg', 2),
(18, 'Ayesha', 'Amara', 'Hello amara kiya haal hai kitny din ho gaey hain tm chuti nai aa rhi ho kheriayt to nai hai na', '2019-09-27 18:16:15', 'images/img2.jpg', 2),
(19, 'Ayesha', 'Uzma', 'Hello Mano how are you', '2019-09-27 18:18:56', 'images/chat_profile.jpg', 2),
(20, 'Ayesha', 'Amara', 'Hello Amara i think you will be fine', '2019-09-27 18:19:54', 'images/chat_profile.jpg', 2),
(21, 'Hadi Niazi', 'Imran Khan', 'Thanku Imran Khan', '2019-09-27 18:33:19', 'images/img.jpg', 3),
(22, 'Ayesha', 'Haroon', 'Hello haroon kesy ho kab se nazar nai aa rhy ap', '2019-09-27 18:36:59', 'images/chat_profile.jpg', 2),
(23, 'Hadi Niazi', 'Akbar', 'Hello akbar kahan ja rhy ho..\r\n', '2019-09-28 09:00:16', 'images/img2.jpg', 3),
(24, 'Hadi Niazi', 'Waqar Khan', 'Hello Waqar how are you ', '2019-09-28 13:40:55', 'images/img.jpg', 3),
(32, 'Hadi Niazi', 'Faheem Khan', 'Faheem sunao kesy ho ', '2019-09-29 11:08:27', NULL, 3);

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(3) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `repeat_password` varchar(30) NOT NULL,
  `status` varchar(10) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `name`, `email`, `password`, `repeat_password`, `status`, `user_id`) VALUES
(1, 'Hadi Niazi', 'admin@testmail.com', '123', '123', 'Online', 3),
(15, 'Waqar', 'admin@gmail.com', '123', '123', 'offline', 2),
(17, 'Ayesha', 'admin@testmail.com', '123', '123', 'Offline', NULL),
(18, 'Abbas', '10', '123', '123', NULL, NULL),
(19, 'Hadi Niazi', 'Jonipk28@gmail.com', '456', '456', 'Online', 0),
(20, 'User1', 'admin@gmail.com', '123', '123', NULL, NULL),
(21, 'Haroon', 'admin@testmail.com', '123', '123', NULL, 15);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
